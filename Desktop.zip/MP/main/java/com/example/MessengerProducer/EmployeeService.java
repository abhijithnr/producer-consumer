package com.example.MessengerProducer;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/emp")
public class EmployeeService {
	@PersistenceContext
	private EntityManager em;
	@Autowired 
	EmployeeDao empDao;
	ArrayList<Employee>emplist=new ArrayList();
/*	@GetMapping(value="/delete/{id}",produces=MediaType.APPLICATION_XML_VALUE)
//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
public void readEmployee(@PathVariable("id")Long id){
		

	empDao.deleteById(id);


	}
	@PostMapping(value="/update/{id}")
	public Employee readEmployee3(@PathVariable("id")Long id){
		
		return empDao.getOne(id);
	}*/
	@PostMapping(value="/update",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Employee updateEmployee(@RequestBody Employee emp){
		Employee e=empDao.getOne(emp.getId());
		if(!(e==null)){
			
		
		if(!(emp.getName()==null)){
			e.setName(emp.getName());
		}
		if(!(emp.getAge()==0)){
			e.setAge(emp.getAge());
		}
		if(!(emp.getSalary()==0)){
			e.setSalary(emp.getSalary());
		}
		System.out.println(emp);
		System.out.println(e);

		empDao.save(e);
		
	}else{
		return emp;
	}
		return emp;
	}
	@PostMapping(value="/insert",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Employee insertEmployee(@RequestBody Employee emp){
		System.out.println(emp);
		emplist.add(emp);
		empDao.save(emp);
		return emp;
	}

@GetMapping(value="/select1/{id}",produces=MediaType.APPLICATION_XML_VALUE)
	public Employee readEmployee1(@PathVariable("id")int id){
		
		return emplist.get(id);
	}
@GetMapping(value="/select/{id}",produces=MediaType.APPLICATION_XML_VALUE)
public Employee readEmployee2(@PathVariable("id")Long id){
	System.out.println("ID"+id);
	return empDao.getOne(id);
}

	@PostMapping(value="/insert/{id}",consumes=MediaType.APPLICATION_XML_VALUE)
	public Employee addEmployee(@RequestBody Employee emp){
	
		emplist.add(emp);
		//System.out.println(emp);
		return emp;
	}
	
	@GetMapping(value="/selectAll",produces=MediaType.APPLICATION_JSON_VALUE)

	public List<Employee> selectAll(){
		
		
		return  empDao.findAll();
		
	}
}

