package com.example.MessageConsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MessgaeConsumer {
	@Autowired 
	RestTemplate restTemplate;
	/*@GetMapping("/consume/{param}")
	public void consume(@PathVariable("param")int param){
		String url="http://localhost:8080/emp/select/"+param;
		restTemplate.getForEntity(url,Employee.class);
	}*/
	@PostMapping("/insert")
	public Employee insert(@RequestBody Employee emp){
		String url="http://localhost:8080/emp/insert";
		//restTemplate.getForEntity(url,Employee.class);
	HttpHeaders headers= new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	//Employee emp= new Employee();
	//emp.setAge(18);emp.setId(122L);emp.setName("Lesly");emp.setSalary(19999);
	HttpEntity<Employee> emp2= new HttpEntity<Employee>(emp,headers);
	String name = restTemplate.postForObject(url,emp2,String.class);
	return emp;
	}
	@PostMapping("/update")
	public Employee update(@RequestBody Employee emp){
		String url="http://localhost:8080/emp/update";
		//restTemplate.getForEntity(url,Employee.class);
	HttpHeaders headers= new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	//Employee emp= new Employee();
	//emp.setAge(18);emp.setId(122L);emp.setName("Lesly");emp.setSalary(19999);
	HttpEntity<Employee> emp2= new HttpEntity<Employee>(emp,headers);
	String name = restTemplate.postForObject(url,emp2,String.class);
	return emp;
	}
	@GetMapping("/select/{param}")
	public Employee find(@PathVariable("param")int param){
		String url="http://localhost:8080/emp/select/"+param;
	
	Employee emp=  restTemplate.getForObject(url,Employee.class);
	
return emp;
	}
	@GetMapping("/selectAll")
	public Employee findAll(){
		String url="http://localhost:8080/emp/selectAll";
	
	Employee name = restTemplate.getForObject(url,Employee.class);
	return name;
	
	}
}
