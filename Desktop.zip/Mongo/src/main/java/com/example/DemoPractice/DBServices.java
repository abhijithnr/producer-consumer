package com.example.DemoPractice;

import java.util.ArrayList;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


public interface DBServices extends MongoRepository<Employee, Long>{//type of id is long


public ArrayList<Employee> findByAge(int age);
public ArrayList<Employee> findBySalary(int salary);
public ArrayList<Employee> findByName(String name);
public boolean existsById(ObjectId id);
public Optional<Employee> findById(ObjectId id);
}
