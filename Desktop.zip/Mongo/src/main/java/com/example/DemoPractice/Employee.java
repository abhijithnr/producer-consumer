package com.example.DemoPractice;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="mongo")// NAme of collection we already have
public class Employee {
	@Id
	private Long id;
private int age;
private int salary;
private String name;

public Employee(Long id, int age, int salary, String name) {
	super();
	this.id = id;
	this.age = age;
	this.salary = salary;
	this.name = name;
}

@Override
public String toString() {
	return "Employee [id=" + id + ", age=" + age + ", salary=" + salary
			+ ", name=" + name + "]";
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
}

