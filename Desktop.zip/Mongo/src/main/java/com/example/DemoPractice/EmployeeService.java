package com.example.DemoPractice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeService {
	@Autowired 
	DBServices service;
	//@PostMapping(value="/insert",consumes=MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/insert")
	public Employee insert(@RequestBody Employee e)
	{
		service.save(e);
		return e;
	}
	@PostMapping("/update/{id}")
	public Employee update(@PathVariable ("id")Long id,@RequestBody Employee e){
	if(service.existsById(id)){
		
		service.save(e);
	}
	else{
		System.out.println("id not found"+id);
		e=null;
	}
		
	
	return  e;
	}
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable ("id")Long id){
		if(service.existsById(id)){
	service.deleteById(id);}
		else{return "Failed";}
		return "SUCCESS";
	}
	@GetMapping("/find/{id}")
	public Optional<Employee> find( @PathVariable ("id")Long id)
	{
		if(!service.existsById(id)){System.out.println("id not found");
		}
		return service.findById(id);
	}
	@GetMapping("/find")
	public List<Employee> findAll( )
	{
	
		return service.findAll();
		
	}
	@GetMapping("/findByAge/{age}")
	public ArrayList<Employee> findByAge(@PathVariable("age")int age)
	{
	
		return service.findByAge(age);
		
	}
	@GetMapping("/findBySalary/{salary}")
	public ArrayList<Employee> findBySalary(@PathVariable("salary")int salary)
	{
	
		return service.findBySalary(salary);
		
	}
	@GetMapping("/findByName/{name}")
	public ArrayList<Employee> findByName(@PathVariable("name")String name)
	{
	
		return service.findByName(name);
		
	}
}
